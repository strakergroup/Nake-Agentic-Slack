def sum(a: int, b: int) -> int:
    """
    Calculate the sum of two integers.
    """
    return a + b


def subtract(a: int, b: int) -> int:
    """
    Calculate the subtraction of two integers.
    """
    return a - b
