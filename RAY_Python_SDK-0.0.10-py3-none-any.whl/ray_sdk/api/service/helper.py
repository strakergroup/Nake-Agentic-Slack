import httpx

def http_wrapper ( method: str, url: str, headers: dict, params = {}, timeout = None, files = None ):
    response = {
        "status": 200,
        "message": "Success",
        "data": ""
    }
    
    try:
        req = httpx.request(
            method = method,
            url = url,
            headers = headers,
            params = params,
            timeout=timeout,
            files = files
        )
        req.raise_for_status()
    except httpx.HTTPStatusError as exc:
        response["status"] = exc.response.status_code
        response["message"] = exc
    except Exception as e:
        response["status"] = 500
        response["message"] = "Internal Server Error"
    else:
        response["status"] = req.status_code
        response["data"] = req.json()

    return response