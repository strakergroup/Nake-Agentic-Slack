from .helper import http_wrapper
class Language:
    str_api_url = ""

    def __init__(self, url ):
        self.str_api_url = url

    def fetch_language(self):
        request = http_wrapper(
            method = "GET",
            headers = {},
            url = self.str_api_url + "/v3/languages"
        )
        return request

    def get_languages(self):
        request = self.fetch_language()
        if request["status"] == 200 and len(list(request["data"]["languages"])):
            return request["data"]["languages"]
            

