
from .helper import http_wrapper

class Job:

    str_api_url = ""
    str_api_token = ""

    def __init__(self, url, token ):
        self.str_api_url = url
        self.str_api_token = token
  
    def fetch_job(self, id: int):
        request = http_wrapper(
            method = "GET",
            url = self.str_api_url + "/v3/jobs?tj=" + str(id),
            headers = { "Authorization": "Bearer " + self.str_api_token }
        ) 
        return request

    def get_job(self, id: int):
        request = self.fetch_job(id = id)
        if request["status"] == 200 and len(list(request["data"]["jobs"])):
            return dict(request["data"]["jobs"][0])
           
            

