# from .service.helper import http_wrapper
# from ray_sdk.api.service.job import Job
class mock:

    str_api_url = ""
    str_api_key = ""

    def __init__(self, url, key):
        self.str_api_url = url
        self.str_api_key = key

    def get_url(self):
        return self.str_api_url

    def set_url(self, url: str):
         self.str_api_url = url

    def set_api_key(self, url: str):    
         self.str_api_key = url
        
    def get_api_key(self):
        return self.str_api_key

    # def fetch_job(self,job_id: int):
    #     request = http_wrapper(
    #         method = "GET",
    #         url = self.str_api_url + "/api/v1/mock/jobs/" + str(job_id),
    #         headers = { "x-api-key": self.str_api_key }
    #     )
    #     return request

