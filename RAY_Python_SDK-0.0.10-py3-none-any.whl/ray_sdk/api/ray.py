
from ray_sdk.api.service.language import Language
from ray_sdk.api.service.job import Job
class Ray:

    str_api_url = ""
    str_api_secret = ""
    str_api_client_id = ""
    str_api_token = ""
    str_api_token_exp = ""

    def __init__(self, url, secret, client_id, token = ""):
        self.str_api_url = url
        self.str_api_secret = secret
        self.str_api_client_id = client_id
        self.str_api_token = token

    def get_url(self):
        return self.str_api_url

    def set_url(self, url: str):
         self.str_api_url = url
    
    def get_token(self):
        return self.str_api_token

    def set_token(self, token: str):
         self.str_api_token = token


    def get_job(self, id: int):
        instance = Job(
            url = self.str_api_url,
            token = self.str_api_token
        )
        return instance.get_job(id = id)

    def get_languages(self):
        instance = Language( url = self.str_api_url )
        return instance.get_languages()

 

