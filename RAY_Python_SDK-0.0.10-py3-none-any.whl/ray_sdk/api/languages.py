from .helper import http_wrapper
import json 

class language:
    str_api_url = ""
    str_api_key = ""
    
    def __init__(self, url, key):
        self.str_api_url = url

    def get_str_api_url(self):
        return self.str_api_url
    def set_str_api_url(self,api_url:str):
        self.str_api_url = api_url 
    def get_str_api_key(self):
        return self.str_api_key
    def set_str_api_key(self,api_key:str):
        self.str_api_key = api_key

    def get_languages(self):
        returnVal = []
        langResult = http_wrapper(
            method="GET",
            url=self.str_api_url + "/v3/languages",
            headers = { "x-api-key": self.str_api_key }
        )
        if langResult["status"] == 200:
            for lang in langResult["data"]["languages"]:
                returnVal.append(lang["name"])
        return returnVal
    