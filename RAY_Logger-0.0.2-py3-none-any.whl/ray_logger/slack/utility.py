from typing import Any, Union
import json
from datetime import datetime


class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        result = None
        if isinstance(o, object):
            if isinstance(o, datetime):
                result = o.isoformat()
            else:
                result = "<non-serializable>"
        else:
            result = json.JSONEncoder.default(self, o)
        return result


def stringify(value: Any) -> Union[str, int, float, None]:
    if value is None or isinstance(value, (str, int, float)):
        return value
    if isinstance(value, (dict, list)):
        return json.dumps(value, cls=DateTimeEncoder, default=str)
    if hasattr(value, "__dict__") and value.__dict__.keys():
        return json.dumps(value.__dict__, cls=DateTimeEncoder, default=str)
    return json.dumps(value, cls=DateTimeEncoder, default=str)


# def objectToJSON(obj: object) -> str:
#     result = None
#     if isinstance(obj,object):
#         if hasattr(obj, '__dict__'):
#             result =  json.dumps(dict(obj), cls=DateTimeEncoder,default=str)
#     return result
