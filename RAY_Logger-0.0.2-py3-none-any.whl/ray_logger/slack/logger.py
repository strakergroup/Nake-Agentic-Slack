from sqlalchemy import text
from sqlalchemy.engine import Engine

from .._base_loggers import MySQLLogger
from .models import SlackAppLog, APILog, SlackLog, WatsonLog


class SlackMySQLLogger(MySQLLogger):
    """Logger that logs events from the Slack app to MySQL."""

    def __init__(
        self,
        engine: Engine,
        slack_log_table: str,
        watson_log_table: str,
        api_log_table: str,
    ) -> None:
        super().__init__(engine)
        self.slack_log_table = slack_log_table
        self.watson_log_table = watson_log_table
        self.api_log_table = api_log_table

    def log(self, log: SlackAppLog) -> int:
        """Logs a Slack app event to the database. The log argument provided
        must contain a `SlackLog` because the `WatsonLog` and `APILog`s use
        the `id` of the inserted `SlackLog`.

        Returns:
            int: The `id` column of the inserted `SlackLog` row.
        """
        if log.slack_log is None:
            raise ValueError(
                "At minimum, the SlackLog must be defined in the SlackAppLog"
            )
        slack_log_id = self.log_slack(log.slack_log)
        if log.watson_log is not None:
            self.log_watson(log.watson_log, slack_log_id)
        for api_log in log.api_logs:
            self.log_api(api_log, slack_log_id)

        return slack_log_id

    def log_slack(self, log: SlackLog) -> int:
        """Logs an entry from a Slack event or action.

        Returns:
            int: The ID of the created log entry.
        """
        with self.engine.begin() as conn:
            # TODO: use table meta?
            sql = text(
                """
                INSERT INTO slack_logs (
                    action_type,
                    action_value,
                    team_id,
                    user_id,
                    client_id,
                    body
                ) VALUES (
                    :action_type,
                    :action_value,
                    :team_id,
                    :user_id,
                    :client_id,
                    :body
                )
            """
            ).bindparams(**log.to_dict())
            result = conn.execute(sql)
        return result.lastrowid

    def log_watson(self, log: WatsonLog, slack_log_id: int) -> int:
        """Logs an entry from an IBM Watson Assistant API response.

        Returns:
            int: The ID of the created log entry.
        """
        with self.engine.begin() as conn:
            sql = text(
                """
                INSERT INTO slack_logs_watson (
                    slack_log_id,
                    status_code,
                    text,
                    response,
                    headers,
                    intents,
                    entities
                ) VALUES (
                    :slack_log_id,
                    :status_code,
                    :text,
                    :response,
                    :headers,
                    :intents,
                    :entities
                )
            """
            ).bindparams(slack_log_id=slack_log_id, **log.to_dict())
            result = conn.execute(sql)
        return result.lastrowid

    def log_api(self, log: APILog, slack_log_id: int) -> int:
        """Logs an entry from a stingRAY API response.

        Returns:
            int: The ID of the created log entry.
        """
        with self.engine.begin() as conn:
            sql = text(
                """
                INSERT INTO slack_logs_api (
                    slack_log_id,
                    status_code,
                    url,
                    payload,
                    response,
                    headers,
                    version
                ) VALUES (
                    :slack_log_id,
                    :status_code,
                    :url,
                    :payload,
                    :response,
                    :headers,
                    :version
                )
            """
            ).bindparams(slack_log_id=slack_log_id, **log.to_dict())
            result = conn.execute(sql)
        return result.lastrowid
