"""The loggers defined in this module are for logging to different places and
are to be extended by loggers for apps.
"""

from sqlalchemy.engine import Engine


class MySQLLogger:
    """Base logger that logs to MySQL."""

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    @property
    def engine(self) -> Engine:
        return self._engine


# TODO:
# class CassandraLogger:
