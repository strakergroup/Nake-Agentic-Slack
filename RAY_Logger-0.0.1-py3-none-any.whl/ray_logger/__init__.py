"""
src
~~~~~~

The src package - a Python package template project that is intended
to be used as a cookie-cutter for developing new Python packages.
"""
