from typing import Any, Union
import json
from datetime import datetime


class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        result = None
        if isinstance(o, object):
            if isinstance(o, datetime):
                result = o.isoformat()
            else:
                result = "<non-serializable>"
        else:
            result = json.JSONEncoder.default(self, o)
        return result


def stringify(value: Any) -> Union[str, int, None]:
    result = None
    if value is not None:
        if not isinstance(value, str) and not isinstance(value, int):
            if hasattr(value, "__dict__") and value.__dict__.keys():
                result = json.dumps(value.__dict__, cls=DateTimeEncoder, default=str)
            else:
                result = json.dumps(value, cls=DateTimeEncoder, default=str)
        else:
            result = value
    return result


# def objectToJSON(obj: object) -> str:
#     result = None
#     if isinstance(obj,object):
#         if hasattr(obj, '__dict__'):
#             result =  json.dumps(dict(obj), cls=DateTimeEncoder,default=str)
#     return result
