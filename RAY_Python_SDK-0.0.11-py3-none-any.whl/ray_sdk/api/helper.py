import httpx

from ..exceptions import RayAPIError, RayAPIResponseError


def http_request(
    method: str,
    url: str,
    headers: dict = {},
    params: dict = {},
    timeout=None,
    files=None,
    raise_for_status: bool = True,
) -> httpx.Response:
    try:
        # TODO: reuse client
        with httpx.Client() as client:
            r = client.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                timeout=timeout,
                files=files,
            )
        if raise_for_status:
            r.raise_for_status()
        return r
    except httpx.HTTPStatusError as e:
        raise RayAPIResponseError(
            "The API returned an error status code",
            request=e.request,
            response=e.response,
        )
    except httpx.RequestError as e:
        raise RayAPIError(
            "There was an error connecting to the API", request=e.request
        ) from e


async def async_request(
    method: str,
    url: str,
    headers: dict = {},
    params: dict = {},
    timeout=None,
    files=None,
    raise_for_status: bool = True,
) -> httpx.Response:
    try:
        # TODO: reuse client
        async with httpx.AsyncClient() as client:
            r = await client.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                timeout=timeout,
                files=files,
            )
        if raise_for_status:
            r.raise_for_status()
        return r
    except httpx.HTTPStatusError as e:
        raise RayAPIResponseError(
            "The API returned an error status code",
            request=e.request,
            response=e.response,
        )
    except httpx.RequestError as e:
        raise RayAPIError(
            "There was an error connecting to the API", request=e.request
        ) from e
