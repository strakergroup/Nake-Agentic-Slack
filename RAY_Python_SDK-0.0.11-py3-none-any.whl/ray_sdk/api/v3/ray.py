from typing import Optional

from .service.job import fetch_job
from .service.language import fetch_languages


class RayV3:
    """The RAY translator service.

    This class uses the stringRAY v3 API.
    """

    DEFAULT_BASE_URL: str = "https://api.strakertranslations.com"

    def __init__(
        self,
        client_id: Optional[str] = None,
        secret: Optional[str] = None,
        token: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        self.client_id = client_id
        self.secret = secret
        self.api_token = token
        self._base_url = base_url or self.DEFAULT_BASE_URL

    @property
    def base_url(self) -> str:
        """The base URL of the stringRAY API.

        Set to `None` or the empty string to reset it to the default base URL.
        """
        return self._base_url

    @base_url.setter
    def base_url(self, base_url: Optional[str]) -> None:
        self._base_url = base_url or self.DEFAULT_BASE_URL

    async def get_job(self, id: str):
        """Gets a job."""
        return await fetch_job(self.base_url, token=self.api_token, id=id)

    async def get_languages(self):
        """Gets all the available languages to translate."""
        return await fetch_languages(self.base_url)
