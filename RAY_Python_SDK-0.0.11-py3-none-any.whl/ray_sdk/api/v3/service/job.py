from ..models import Job
from ...helper import async_request
from ....exceptions import RayAPIError, RayAPIResponseError, RayAuthError


async def fetch_job(base_url: str, token: str, id: str) -> Job:
    try:
        r = await async_request(
            method="GET",
            url=f"{base_url}/v3/jobs",
            params={"id": str(id)},
            headers={"Authorization": f"Bearer {token}"},
        )
    except RayAPIResponseError as e:
        if e.response.status_code in (401, 403, 404):
            raise RayAuthError("Unauthorized access to job")
        raise

    try:
        data = r.json()
        job_data = data["data"]["jobs"][0]
        return Job(
            id=job_data["id"],
            uuid=job_data["obj_uuid"],
            status=job_data["status"],
            sl=job_data["sl"],
            tl=job_data["tl"],
            target_date=job_data["target_date"],
            created_at=job_data["created_at"],
        )
    except Exception:
        raise RayAPIError("The API response format is invalid")
