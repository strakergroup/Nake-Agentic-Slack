import httpx


class RayError(Exception):
    """The base exception for the RAY sdk."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


class RayAPIError(RayError):
    """Exception related to the RAY API."""

    def __init__(self, message: str, request: httpx.Request) -> None:
        super().__init__(message)
        self._request = request

    @property
    def request(self) -> httpx.Request:
        return self.request


class RayAPIResponseError(RayAPIError):
    """Exception related to the response of a RAY API request, e.g. the
    response returned an error status code (not 2XX).
    """

    def __init__(
        self, message: str, request: httpx.Request, response: httpx.Response
    ) -> None:
        super().__init__(message, request)
        self._response = response

    @property
    def response(self) -> httpx.Response:
        return self._response


class RayAuthError(RayError):
    """Exception for unauthorized access to a resource."""

    pass
