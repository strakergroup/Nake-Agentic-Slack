import datetime
from enum import Enum
from dataclasses import dataclass


class Workflow(str, Enum):
    """The job workflow types."""

    TRANSLATION = "TRANSLATION"
    """Fast translation for general use."""
    TRANSLATION_REVIEW = "TRANSLATION_REVIEW"
    """Translation and Review for professional use."""
    TRANSLATION_REVIEW_VALIDATION = "TRANSLATION_REVIEW_VALIDATION"
    """Translation and Review plus extra Validation for proofreading."""
    TRANSLATION_VALIDATION = "TRANSLATION_VALIDATION"
    """Translation and Validation for proofreading."""


@dataclass
class Job:
    """The model for a translation job."""

    id: str
    uuid: str
    status: str
    sl: str
    tl: str
    target_date: datetime.datetime
    created_at: datetime.datetime

    def __post_init__(self) -> None:
        if isinstance(self.target_date, str):
            self.target_date = datetime.datetime.strptime(self.target_date, "%d/%m/%Y")
        if isinstance(self.created_at, str):
            self.created_at = datetime.datetime.strptime(self.created_at, "%d/%m/%Y")


@dataclass
class Language:
    """A language which can be translated."""

    code: str
    name: str
