import os

"""
__version__.py
~~~~~~~~~~~~~~

Information about the current version of the ray-python-sdk package.
"""

__title__ = os.getenv("TITLE")
__description__ = os.getenv("DESCRIPTION")
__version__ = os.getenv("VERSION")
__author__ = os.getenv("AUTHOR")
__author_email__ = os.getenv("AUTHOR_EMAIL")
__license__ = os.getenv("LICENCE")
__url__ = os.getenv("URL")
