from typing import Optional
import httpx


class RayError(Exception):
    """The base exception for the RAY sdk."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


class RayAPIError(RayError):
    """Exception related to the RAY API."""

    def __init__(self, message: str, request: httpx.Request) -> None:
        super().__init__(message)
        self._request = request

    @property
    def request(self) -> httpx.Request:
        return self.request

    @classmethod
    def from_httpx(cls, message: str, exc: httpx.HTTPError):
        return cls(message, request=exc.request)


class RayAPIResponseError(RayAPIError):
    """Exception related to the response of a RAY API request, e.g. the
    response returned an error status code (not 2XX).
    """

    def __init__(
        self,
        message: str,
        request: httpx.Request,
        response: httpx.Response,
    ) -> None:
        super().__init__(message, request)
        self._response = response

    @property
    def response(self) -> httpx.Response:
        return self._response

    @classmethod
    def from_httpx(cls, message: str, exc: httpx.HTTPStatusError):
        return cls(message, request=exc.request, response=exc.response)


class RayAuthError(RayError):
    """Exception for unauthorized access to a resource."""

    def __init__(
        self,
        message: str,
        api_token: Optional[str] = None,
        response: Optional[httpx.Response] = None,
    ) -> None:
        super().__init__(message)
        self._api_token = api_token
        self._response = response

    @property
    def api_token(self) -> Optional[str]:
        """The API token used to authenticate the request."""
        return self._api_token

    @property
    def response(self) -> Optional[httpx.Response]:
        """The response from the API if applicable."""
        return self._response
