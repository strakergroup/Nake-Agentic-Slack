from typing import Optional
import json
import httpx

from ..exceptions import RayAPIError, RayAPIResponseError


# Only support async HTTP requests for now.


async def async_request(
    method: str,
    url: str,
    api_token: Optional[str] = None,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    files: Optional[httpx._types.RequestFiles] = None,
    headers: Optional[dict] = None,
    raise_for_status: bool = True,
    **kwargs,
) -> httpx.Response:
    """Make an async HTTP request. This a wrapper around httpx that raises
    `RayError`s instead of httpx exceptions.
    """
    if api_token:
        if headers is None:
            headers = {}
        headers["Authorization"] = f"Bearer {api_token}"

    try:
        # TODO: reuse client
        async with httpx.AsyncClient() as client:
            r = await client.request(
                method=method,
                url=url,
                params=params,
                data=data,
                files=files,
                headers=headers,
                **kwargs,
            )
        if raise_for_status:
            r.raise_for_status()

            try:
                data = r.json()
                # Raise an error for an API error responses.
                if "success" in data and not data["success"]:
                    raise RayAPIResponseError(
                        "The API returned an error response",
                        request=r.request,
                        response=r,
                    )
            except json.JSONDecodeError:
                pass  # Can't check error in body if not json.
        return r
    except httpx.HTTPStatusError as e:
        raise RayAPIResponseError.from_httpx("The API returned an error status code", e)
    except httpx.RequestError as e:
        raise RayAPIError.from_httpx(
            "There was an error connecting to the API", e
        ) from e
