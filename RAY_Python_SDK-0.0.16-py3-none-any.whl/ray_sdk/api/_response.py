from typing import TypeVar, Generic
import httpx


T = TypeVar("T")


class RayResponse(Generic[T]):
    """A wrapper around httpx.Response which contains the formatted data
    returned from the request.
    """

    def __init__(self, response: httpx.Response, data: T) -> None:
        self._response = response
        self._data = data

    @property
    def response(self) -> httpx.Response:
        return self._response

    @property
    def data(self) -> T:
        return self._data

    @property
    def status_code(self) -> int:
        return self.response.status_code
