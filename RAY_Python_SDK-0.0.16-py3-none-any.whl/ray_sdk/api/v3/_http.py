from typing import Optional, Union
import os
import json
from urllib.parse import urlencode

from .models import Language, Job, Workflow
from .._request import async_request
from .._response import RayResponse
from ...exceptions import RayAPIResponseError, RayAuthError


def _require_api_token(token: Optional[str]):
    # TODO: convert to decorator
    if not token:
        raise RayAuthError("An API token is required", api_token=token)


async def fetch_job(base_url: str, token: str, id: str) -> RayResponse[Job]:
    _require_api_token(token)
    try:
        r = await async_request(
            method="GET",
            url=f"{base_url}/v3/translate/jobs",
            api_token=token,
            params={"id": str(id)},
        )
    except RayAPIResponseError as e:
        if e.response.status_code in (401, 403, 404):
            raise RayAuthError(
                "Unauthorized access to job", api_token=token, response=e.response
            )
        raise

    try:
        json_data = r.json()
        if not json_data.get("jobs"):
            raise RayAuthError(
                "Unauthorized access to job", api_token=token, response=r
            )
        job_data = json_data["jobs"][0]
        data = Job(
            id=job_data["id"],
            uuid=job_data["uuid"],
            status=job_data["status"],
            sl=Language(**job_data["sl"]),
            tl=[Language(**lang) for lang in job_data["tl"]],
            target_date=job_data["target_date"],
            created_at=job_data["created_at"],
        )
        return RayResponse(r, data)
    except (json.JSONDecodeError, KeyError, IndexError):
        raise RayAPIResponseError(
            "The API response format is invalid",
            request=r.request,
            response=r,
        )


async def new_job(
    base_url: str,
    token: str,
    file_path: str,
    title: str,
    sl: str,
    tl: Union[str, list[str]],
    workflow: Optional[Union[Workflow, str]] = None,
    callback_uri: Optional[str] = None,
    additional_data: Optional[dict] = None,
) -> RayResponse[None]:
    _require_api_token(token)
    # First validate the arguments.
    if not file_path or not os.path.isfile(file_path):
        raise ValueError("The file_path argument must be the path of a file")
    if isinstance(tl, list):
        if not tl:
            raise ValueError("The tl argument must contain at least one language")
        tl = ",".join(tl)
    # Check if the workflow type is a valid value.
    if isinstance(workflow, Workflow):
        workflow = workflow.value
    elif isinstance(workflow, str):
        workflow = workflow.upper()
        if workflow not in Workflow._value2member_map_:
            raise ValueError(
                "The workflow argument must be a valid workflow type or None"
            )

    payload = {
        "title": title,
        "sl": sl,
        "tl": tl,
        "workflow": workflow,
        "callback_uri": callback_uri,
    }
    if additional_data:
        payload.update(additional_data)
    try:
        r = await async_request(
            method="POST",
            url=f"{base_url}/v3/translate/file",
            data=payload,
            files={"source_file": open(file_path, "rb")},
            headers={"Authorization": f"Bearer {token}"},
        )
        return RayResponse(r, None)
    except RayAPIResponseError as e:
        if e.response.status_code in (401, 403, 404):
            raise RayAuthError(
                "Unauthorized access to submit a new job",
                api_token=token,
                response=e.response,
            )
        raise


async def fetch_languages(base_url: str) -> RayResponse[list[Language]]:
    r = await async_request(method="GET", url=f"{base_url}/v3/languages")
    try:
        json_data = r.json()
        data = [Language(**lang) for lang in json_data["languages"]]
        return RayResponse(r, data)
    except (json.JSONDecodeError, KeyError, TypeError):
        raise RayAPIResponseError(
            "The API response format is invalid", request=r.request, response=r
        )


async def exec_api_ondemand_process(
    base_url: str, token: str, app_source: str
) -> RayResponse[None]:
    _require_api_token(token)
    query_params = urlencode({"app_source": app_source})
    r = await async_request(
        method="GET",
        url=f"{base_url}/v3/translate/ondemandprocess?{query_params}",
        headers={"Authorization": f"Bearer {token}"},
    )
    return RayResponse(r, None)
