from typing import Optional, Union
import os
import json

from ..models import Job, Workflow
from ...helper import async_request
from ....exceptions import RayAPIResponseError, RayAuthError


async def fetch_job(base_url: str, token: str, id: str) -> Job:
    try:
        r = await async_request(
            method="GET",
            url=f"{base_url}/v3/translate/jobs",
            params={"id": str(id)},
            headers={"Authorization": f"Bearer {token}"},
        )
    except RayAPIResponseError as e:
        if e.response.status_code in (401, 403, 404):
            raise RayAuthError("Unauthorized access to job")
        raise

    try:
        data = r.json()
        if not data.get("jobs"):
            raise RayAuthError("Unauthorized access to job")
        job_data = data["jobs"][0]
        return Job(
            id=job_data["id"],
            uuid=job_data["uuid"],
            status=job_data["status"],
            sl=job_data["sl"],
            tl=job_data["tl"],
            target_date=job_data["target_date"],
            created_at=job_data["created_at"],
        )
    except (json.JSONDecodeError, KeyError, IndexError):
        raise RayAPIResponseError(
            "The API response format is invalid",
            request=r.request,
            response=r,
        )


async def new_job(
    base_url: str,
    token: str,
    file_path: str,
    title: str,
    sl: str,
    tl: Union[str, list[str]],
    workflow: Optional[Union[Workflow, str]] = None,
    callback_uri: Optional[str] = None,
    additional_data: Optional[dict] = None,
) -> None:
    # First validate the arguments.
    if not file_path or not os.path.isfile(file_path):
        raise ValueError("The file_path argument must be the path of a file")
    if isinstance(tl, list):
        if not tl:
            raise ValueError("The tl argument must contain at least one language")
        tl = ",".join(tl)
    # Check if the workflow type is a valid value.
    if isinstance(workflow, Workflow):
        workflow = workflow.value
    elif isinstance(workflow, str):
        workflow = workflow.upper()
        if workflow not in Workflow._value2member_map_:
            raise ValueError(
                "The workflow argument must be a valid workflow type or None"
            )

    payload = {
        "title": title,
        "sl": sl,
        "tl": tl,
        "workflow": workflow,
        "callback_uri": callback_uri,
    }
    if additional_data:
        payload.update(additional_data)
    try:
        await async_request(
            method="POST",
            url=f"{base_url}/v3/translate/file",
            data=payload,
            files={"source_file": open(file_path, "rb")},
            headers={"Authorization": f"Bearer {token}"},
        )
    except RayAPIResponseError as e:
        if e.response.status_code in (401, 403, 404):
            raise RayAuthError("Unauthorized access to submit a new job")
        raise
