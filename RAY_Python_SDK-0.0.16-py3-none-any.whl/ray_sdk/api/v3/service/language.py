from ..models import Language
from ...helper import async_request
from ....exceptions import RayAPIError


async def fetch_languages(base_url: str) -> list[Language]:
    r = await async_request(method="GET", url=f"{base_url}/v3/languages")
    data = r.json()
    try:
        return [Language(**lang) for lang in data["languages"]]
    except Exception:
        raise RayAPIError("The API response format is invalid")
