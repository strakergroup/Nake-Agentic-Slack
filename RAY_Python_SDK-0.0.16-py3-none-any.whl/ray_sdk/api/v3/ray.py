from typing import Optional, Union

from .models import Job, Language, Workflow
from ._http import fetch_job, new_job, fetch_languages, exec_api_ondemand_process
from .._response import RayResponse


class RayV3:
    """The RAY translator service.

    This class uses the stingRAY v3 API.
    """

    DEFAULT_BASE_URL: str = "https://api.strakertranslations.com"

    def __init__(
        self,
        api_token: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        self.api_token = api_token
        self.base_url = base_url

    @property
    def base_url(self) -> str:
        """The base URL of the stringRAY API.

        Set to `None` or the empty string to reset it to the default base URL.
        """
        return self._base_url

    @base_url.setter
    def base_url(self, base_url: Optional[str]) -> None:
        self._base_url = base_url.rstrip("/") if base_url else self.DEFAULT_BASE_URL

    async def get_job(self, id: str) -> RayResponse[Job]:
        """Gets the details of a translation job.

        Args:
            id (str): The reference number.

        Returns:
            Job: The translation job detais.
        """
        return await fetch_job(self.base_url, token=self.api_token, id=id)

    async def new_job(
        self,
        file_path: str,
        title: str,
        sl: str,
        tl: Union[str, list[str]],
        workflow: Optional[Union[Workflow, str]] = None,
        callback_uri: Optional[str] = None,
        additional_data: Optional[dict] = None,
    ) -> RayResponse[None]:
        """Submits a new job.

        Args:
            file_path (str): The path of the file to upload
            title (str): The title of the job.
            sl (str): The source language code.
            tl (list[str]): The codes of the target languages.
            workflow (Optional[str], optional): The workflow. Defaults to None.
            callback_uri (Optional[str], optional): The callback URI for webhooks.
                Defaults to None.
            additional_data (Optional[dict], optional): Additional data to put in
                the body. Defaults to None.

        Raises:
            ValueError: Invalid arguments were given.
        """
        return await new_job(
            self.base_url,
            self.api_token,
            file_path=file_path,
            title=title,
            sl=sl,
            tl=tl,
            workflow=workflow,
            callback_uri=callback_uri,
            additional_data=additional_data,
        )

    async def get_languages(self) -> RayResponse[list[Language]]:
        """Gets all the available languages to translate."""
        return await fetch_languages(self.base_url)

    async def api_ondemand_process(
        self, app_source: str = "public"
    ) -> RayResponse[None]:
        """Executes on-demand APIv3 auto process for TJ creation"""
        return await exec_api_ondemand_process(
            self.base_url, self.api_token, app_source
        )
