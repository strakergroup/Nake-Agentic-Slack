from typing import Optional
import json
import httpx

from ..exceptions import RayAPIError, RayAPIResponseError


def http_request(
    method: str,
    url: str,
    headers: Optional[dict] = None,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    files=None,
    timeout=None,
    raise_for_status: bool = True,
) -> httpx.Response:
    try:
        # TODO: reuse client
        with httpx.Client() as client:
            r = client.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                data=data,
                files=files,
                timeout=timeout,
            )
        if raise_for_status:
            r.raise_for_status()

            try:
                data = r.json()
                # Raise an error for an API error responses.
                if "success" in data and not data["success"]:
                    raise RayAPIResponseError(
                        "The API returned an error response",
                        request=r.request,
                        response=r,
                    )
            except json.JSONDecodeError:
                pass  # Can't check error in body if not json.
        return r
    except httpx.HTTPStatusError as e:
        raise RayAPIResponseError(
            "The API returned an error status code",
            request=e.request,
            response=e.response,
        )
    except httpx.RequestError as e:
        raise RayAPIError(
            "There was an error connecting to the API", request=e.request
        ) from e


async def async_request(
    method: str,
    url: str,
    headers: Optional[dict] = None,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    files=None,
    timeout=None,
    raise_for_status: bool = True,
) -> httpx.Response:
    try:
        # TODO: reuse client
        async with httpx.AsyncClient() as client:
            r = await client.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                data=data,
                files=files,
                timeout=timeout,
            )
        if raise_for_status:
            r.raise_for_status()

            try:
                data = r.json()
                # Raise an error for an API error responses.
                if "success" in data and not data["success"]:
                    raise RayAPIResponseError(
                        "The API returned an error response",
                        request=r.request,
                        response=r,
                    )
            except json.JSONDecodeError:
                pass  # Can't check error in body if not json.
        return r
    except httpx.HTTPStatusError as e:
        raise RayAPIResponseError(
            "The API returned an error status code",
            request=e.request,
            response=e.response,
        )
    except httpx.RequestError as e:
        raise RayAPIError(
            "There was an error connecting to the API", request=e.request
        ) from e
