from typing import Optional
import json

from ..models import Job
from ...helper import async_request
from ....exceptions import RayAPIError, RayAPIResponseError, RayAuthError


async def fetch_job(base_url: str, token: str, id: str) -> Job:
    try:
        r = await async_request(
            method="GET",
            url=f"{base_url}/v3/translate/jobs",
            params={"id": str(id)},
            headers={"Authorization": f"Bearer {token}"},
        )
    except RayAPIResponseError as e:
        if e.response.status_code in (401, 403, 404):
            raise RayAuthError("Unauthorized access to job")
        raise

    try:
        data = r.json()
        if not data.get("jobs"):
            raise RayAuthError("Unauthorized access to job")
        job_data = data["jobs"][0]
        return Job(
            id=job_data["id"],
            uuid=job_data["obj_uuid"],
            status=job_data["status"],
            sl=job_data["sl"],
            tl=job_data["tl"],
            target_date=job_data["target_date"],
            created_at=job_data["created_at"],
        )
    except (json.JSONDecodeError, KeyError):
        raise RayAPIResponseError(
            "The API response format is invalid",
            request=r.request,
            response=r,
        )


async def new_job(
    base_url: str,
    token: str,
    file_path: str,
    title: str,
    sl: str,
    tl: list[str],
    workflow: Optional[str] = None,
) -> None:
    # TODO validation
    try:
        r = await async_request(
            method="POST",
            url=f"{base_url}/v3/translate/file",
            data={"title": title, "sl": sl, "tl": ",".join(tl), "workflow": workflow},
            files={"source_file": open(file_path, "rb")},
            headers={"Authorization": f"Bearer {token}"},
        )
    except RayAPIResponseError as e:
        if e.response.status_code in (401, 403, 404):
            print(e)
            raise RayAuthError("Unauthorized access to submit a new job")
        raise

    try:
        data = r.json()
        print(data)
        # job_data = data["data"]["jobs"][0]
        # return Job(
        #     id=job_data["id"],
        #     uuid=job_data["obj_uuid"],
        #     status=job_data["status"],
        #     sl=job_data["sl"],
        #     tl=job_data["tl"],
        #     target_date=job_data["target_date"],
        #     created_at=job_data["created_at"],
        # )
    except (json.JSONDecodeError, KeyError):
        raise RayAPIResponseError(
            "The API response format is invalid", request=r.request, response=r
        )
