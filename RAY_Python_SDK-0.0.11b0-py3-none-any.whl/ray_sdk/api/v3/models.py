import datetime
from dataclasses import dataclass


@dataclass
class Job:
    id: str
    uuid: str  # TODO use link instead
    status: str
    sl: str  # TODO use Language class
    tl: str
    target_date: datetime.datetime
    created_at: datetime.datetime

    def __post_init__(self) -> None:
        # TODO API should return ISO format for dates
        if isinstance(self.target_date, str):
            self.target_date = datetime.datetime.strptime(
                self.target_date, "%d/%m/%Y"
            )
        if isinstance(self.created_at, str):
            self.created_at = datetime.datetime.strptime(
                self.created_at, "%d/%m/%Y"
            )


@dataclass
class Language:
    """A language which can be translated."""

    code: str
    name: str
