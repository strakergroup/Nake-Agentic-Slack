from typing import Optional
import httpx

from ..exceptions import RayAPIError, RayAPIResponseError


def http_request(
    method: str,
    url: str,
    headers: Optional[dict] = None,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    files=None,
    timeout=None,
    raise_for_status: bool = True,
) -> httpx.Response:
    try:
        # TODO: reuse client
        with httpx.Client() as client:
            r = client.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                data=data,
                files=files,
                timeout=timeout,
            )
        if raise_for_status:
            r.raise_for_status()
        return r
    except httpx.HTTPStatusError as e:
        raise RayAPIResponseError(
            "The API returned an error status code",
            request=e.request,
            response=e.response,
        )
    except httpx.RequestError as e:
        raise RayAPIError(
            "There was an error connecting to the API", request=e.request
        ) from e


async def async_request(
    method: str,
    url: str,
    headers: Optional[dict] = None,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    files=None,
    timeout=None,
    raise_for_status: bool = True,
) -> httpx.Response:
    try:
        # TODO: reuse client
        async with httpx.AsyncClient() as client:
            r = await client.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                data=data,
                timeout=timeout,
                files=files,
            )
        if raise_for_status:
            r.raise_for_status()

            try:
                data = r.json()
                # Raise an error for API error responses.
                if not data.get("success", False):
                    raise RayAPIResponseError(
                        "The API returned an error response",
                        request=r.request,
                        response=r,
                    )
            except Exception:
                pass
        return r
    except httpx.HTTPStatusError as e:
        raise RayAPIResponseError(
            "The API returned an error status code",
            request=e.request,
            response=e.response,
        )
    except httpx.RequestError as e:
        print(e)
        raise RayAPIError(
            "There was an error connecting to the API", request=e.request
        ) from e
