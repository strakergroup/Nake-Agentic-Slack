from typing import Any, Optional, Union
from abc import ABC, abstractmethod
from dataclasses import dataclass, asdict

from .utility import stringify


class DictLog(ABC):
    """An abstract base class for a log entry which can be serialized to a dict."""

    @abstractmethod
    def to_dict(self) -> dict[str, Any]:
        raise NotImplementedError()


@dataclass
class SlackLog(DictLog):
    """A log entry for a Slack event or action.

    Args:
        action_type - Required [str]:
            Type of event or action received from Slack, e.g. event, action,
                command, shortcut.
        action_value - Required [str]:
            Value of event or action received from Slack, e.g. message (event),
                /ray (command).
        user_id - Optional [str]:
            The user ID of the Slack event.
        team_id - Optional [str]:
            The team ID of the Slack event.
        channel_id - Optional [str]:
            The channel ID of the Slack event.
        body - Optional [dict] -> Stored as JSON:
            The body of the Slack request.
        ts - Optional [str]:
            The Slack timestamp of the event or action.
        client_id - Optional [str]:
            The Straker Deltaray ID (if it is applicable).
    """

    action_type: Optional[str]
    action_value: Optional[str]
    user_id: Optional[str]
    team_id: Optional[str]
    channel_id: Optional[str]
    body: Optional[Union[dict[str, Any], str]]
    ts: Optional[str] = None
    client_id: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        dict_ = asdict(self)
        for key, val in dict_.items():
            dict_[key] = stringify(val)
        return dict_


@dataclass
class APILog(DictLog):
    """A log entry for a response from the stingRAY API.

    Args:
        status_code - [int]:
            status_code of the request
        url - [str]:
            URL of the request
        payload - [dict]:
            payload of the API request.
        response - [dict]:
            response of the API request.
        headers - [dict]:
            headers of the API request.
        version - [str]
            version of the API

    Returns:
        Straker API Log Model
    """

    status_code: int
    url: str
    payload: Optional[Union[dict[str, Any], str]]
    response: Optional[Union[dict[str, Any], str]]
    headers: Optional[dict[str, str]]
    version: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        dict_ = asdict(self)
        for key, val in dict_.items():
            dict_[key] = stringify(val)
        return dict_


@dataclass
class WatsonLog(DictLog):
    """A log entry for a response from the IBM Watson assistant API.

    Args:
        status_code - [int]:
            status_code of the request
        text - [str]:
            the text sent to Watson Assistant.
        response - [dict]:
            response of the API request.
        headers - [dict]:
            headers of the API request.
        intents - [list[dict]]
            intent from the processed data from the API
        entities - [list[dict]]
            entities from the processed data from the API

    Returns:
        IBM Watson Log Model
    """

    status_code: int
    text: Optional[str]
    response: Optional[Union[dict[str, Any], str]]
    headers: Optional[dict[str, str]]
    intents: Optional[list[dict[str, Any]]]
    entities: Optional[list[dict[str, Any]]]

    def to_dict(self) -> dict[str, Any]:
        dict_ = asdict(self)
        for key, val in dict_.items():
            dict_[key] = stringify(val)
        return dict_


@dataclass
class CallbackLog(DictLog):
    """
    Entity to handle Ray logs for Straker API Callback.

    Args:
        body - Optional [dict] -> Stored as JSON:
            Callback body.

    Returns:
        Straker API Log Model
    """

    body: Optional[Union[dict[str, Any], str]] = None

    def to_dict(self) -> dict[str, Any]:
        dict_ = asdict(self)
        for key, val in dict_.items():
            dict_[key] = stringify(val)
        return dict_


class SlackAppLog:
    """An event from the Slack app to be logged. This may include multiple log
    entries, e.g. from Slack, from Watson, from the API.
    """

    def __init__(
        self,
        slack: Optional[SlackLog] = None,
        watson: Optional[WatsonLog] = None,
        api: Optional[list[APILog]] = None,
    ) -> None:
        self.slack_log = slack
        self.watson_log = watson
        self.api_logs = api

    @property
    def slack_log(self) -> Optional[SlackLog]:
        return self._slack_log

    @slack_log.setter
    def slack_log(self, log: SlackLog) -> None:
        self._slack_log = log

    @property
    def watson_log(self) -> Optional[WatsonLog]:
        return self._watson_log

    @watson_log.setter
    def watson_log(self, log: WatsonLog) -> None:
        self._watson_log = log

    @property
    def api_logs(self) -> list[APILog]:
        return self._api_logs

    @api_logs.setter
    def api_logs(self, logs: Optional[list[APILog]]) -> None:
        self._api_logs = logs if logs is not None else []

    def set_slack_log(
        self,
        action_type: Optional[str],
        action_value: Optional[str],
        user_id: Optional[str],
        team_id: Optional[str],
        channel_id: Optional[str],
        body: Optional[Union[dict[str, Any], str]],
        ts: Optional[str] = None,
        client_id: Optional[str] = None,
    ) -> None:
        self.slack_log = SlackLog(
            action_type=action_type,
            action_value=action_value,
            user_id=user_id,
            team_id=team_id,
            channel_id=channel_id,
            body=body,
            ts=ts,
            client_id=client_id,
        )

    def set_watson_log(
        self,
        status_code: int,
        text: Optional[str],
        response: Optional[Union[dict[str, Any], str]],
        headers: Optional[dict[str, str]],
        intents: Optional[list[dict[str, Any]]],
        entities: Optional[list[dict[str, Any]]],
    ) -> None:
        self.watson_log = WatsonLog(
            status_code=status_code,
            text=text,
            response=response,
            headers=headers,
            intents=intents,
            entities=entities,
        )

    def add_api_log(
        self,
        status_code: int,
        url: str,
        payload: Optional[Union[dict[str, Any], str]],
        response: Optional[Union[dict[str, Any], str]],
        headers: Optional[dict[str, str]],
        version: Optional[str] = None,
    ) -> None:
        self._api_logs.append(
            APILog(
                status_code=status_code,
                url=url,
                payload=payload,
                response=response,
                headers=headers,
                version=version,
            )
        )

    @classmethod
    def from_slack(
        cls,
        action_type: Optional[str],
        action_value: Optional[str],
        user_id: Optional[str],
        team_id: Optional[str],
        channel_id: Optional[str],
        body: Optional[Union[dict[str, Any], str]],
        ts: Optional[str] = None,
        client_id: Optional[str] = None,
    ) -> "SlackAppLog":
        log = cls()
        log.set_slack_log(
            action_type=action_type,
            action_value=action_value,
            user_id=user_id,
            team_id=team_id,
            channel_id=channel_id,
            body=body,
            ts=ts,
            client_id=client_id,
        )

        return log
